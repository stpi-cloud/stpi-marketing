╔══════════════════════════════════════════════════════════════════╗
║  STPI 1.0.1 — FREE DEMO      Jobs found. Letters written. You tap ║
║  approve. It sends. (And yes — this banner is what the paid      ║
║  build does NOT have.)                                           ║
╚══════════════════════════════════════════════════════════════════╝

YOU HAVE: the actual product. Same code our paying agencies run,
on a demo leash: 25 drafted applications · 5 real email sends · 30 days.
Everything else — PDFs, Discord/Telegram approvals, dashboard — is uncut.

5 MINUTES TO FIRST SIGHT:
  python3.12 -m venv .venv && source .venv/bin/activate
  pip install stpi-1.0.1-py3-none-any.whl
  stpi keygen >> .env            # encrypts the keys you paste next (both free):
  #   groq.com -> free API key  ->  stpi encrypt gsk_...  -> paste into config/tenants/demo/tenant.yaml
  #   optional: a Gmail app password for the mailbox block (or leave blank and run --dry)
  stpi hunt --dry                # watch it find, score and draft REAL jobs — no email leaves the box
  stpi serve                     # dashboard http://localhost:8080 (demo strip included, by design)
  stpi doctor                    # what's set / what's missing

FEEDBACK LOOP: when a draft lands in your Discord card, tap ✅ and one of your
5 demo sends goes out — from your mailbox, signed as the candidate, to the real ad's address.
That moment is what $306/mo (about R4,999) buys. Annual prepay: $2,754/yr (about R45,000), 25% off.

  🔓 UPGRADE: https://whop.com/stpi      (card, instant activation)
     ⚡ Lightning: SharkSkin@coinos.io
     🇿🇼🇿🇦 Mukuru / EFT: Mukuru / EFT: +263 78 460 0904 · ref = your tenant id
     or message simalidudu@gmail.com — a human answers.

SHARING: the whole point. Re-send this ZIP to your other coaches, unmodified (see LICENSE
clause 2). Every one of them gets the same 30 days to feel the leash.

integrity: sha256 14d48b48957c0a998a22a753806af4addfb6600666b631cac5ab5db0e4145085
