# STPi 21-Country ATS & Executive CV Compliance Checklist

Every CV rendered by STPi (across all 12 house designs: **Classic, Indigo, Emerald, Sunset, Modern, Aurora, Mono, Apex Executive, Slate, Onyx, Coral, and Vine**) adheres to regional recruiter and ATS expectations across our **21 supported countries** and **35 job board families**:

## 1. Southern Africa (`ZA`, `ZW`, `ZM`, `BW`, `MZ`, `NA`, `MW`, `LS`, `SZ`, `AO`)
- **South Africa (`ZA` — PNet, CareerJunction, Careers24, JobMail, OfferZen, Bizcommunity)**:
  - Include NQF level / SAQA evaluation note where applicable, professional body registration (`SAICA`, `ECSA`, `HPCSA`, `SABPP`), notice period, and city/province.
  - Keep layout clean single-column or structured executive two-column (`Apex`, `Classic`, `Indigo`, `Slate`) — no text hidden inside graphic shapes.
- **Zimbabwe & Zambia (`ZW`, `ZM` — Classifieds.co.zw, VacanciesMail, iHarareJobs, CVPeopleAfrica, GoZambiaJobs)**:
  - Include clear academic progression (Honours degree + professional charter such as `ACCA`, `CIMA`, `CIS`, `ZICA`), drivers licence class, and reachable WhatsApp + email contact header.
  - Attach academic & professional certificates as clean trailing pages in the **same single PDF** (STPi `render_document()` merges Page 1 Cover Letter + Page 2 CV + trailing Certificates automatically).
- **Botswana, Namibia, Mozambique, Malawi, Lesotho, Eswatini, Angola (`BW`, `NA`, `MZ`, `MW`, `LS`, `SZ`, `AO`)**:
  - State work-authorization / citizenship clearly in the header strip and match language (English or Portuguese for `MZ`/`AO`) to the vacancy advertisement.

## 2. East Africa & Indian Ocean (`KE`, `TZ`, `UG`, `RW`, `BI`, `MG`, `MU`, `SC`, `KM`)
- **Kenya, Tanzania, Uganda, Rwanda, Burundi (`BrighterMonday`, `Fuzu`, `MyJobMag`, `JobwebKenya`, `JobinRwanda`, `ZoomTanzania`)**:
  - Highlight regional East African Community (EAC) experience, donor/NGO or multinational reporting standards where relevant, and quantifiable KPIs in every role bullet.
- **Mauritius, Seychelles, Madagascar, Comoros (`MyJob.mu`, `CareerHub.mu`, `ReliefWeb`)**:
  - Bilingual clarity (English/French where applicable) and international financial/hospitality/tech certifications prominently listed.

## 3. Central Africa & Global Remote (`CD`, `CG` + Remote Global Boards)
- **DRC & Republic of Congo (`CD`, `CG` — MediaCongo, Emploi.cd, ReliefWeb, UNJobs, Devex)**:
  - Emphasize multi-site operations, French/English proficiency, and international compliance standards.
- **Global Remote Boards (`RemoteOK`, `Remotive`, `WorkingNomads`, `WeWorkRemotely`, `Himalayas`, `Jobicy`, `Arbeitnow`)**:
  - Emphasize UTC/CAT timezone overlap (`UTC+2`, 100% overlap with UK/EU business hours), async communication tools, and direct portfolio/GitHub/LinkedIn links.

## 4. Pre-Send 7-Point Quality Gate
1. **Single Combined PDF**: Cover Letter (Page 1) + Executive CV (Page 2–3) + Certificates (trailing pages).
2. **Zero Fabricated Claims**: Every date, employer, title, and metric matches your YAML Truth-File.
3. **Exact Vacancy Title Match**: Your cover letter subject line and opening paragraph cite the exact vacancy title and company name.
4. **Quantified Impact**: At least 2 bullets per recent role include a concrete number (%, $, days saved, headcount, or volume).
5. **Verified Mailbox**: Sent from your own verified mailbox (`#settings` -> `Test mailbox`) so employer replies come straight back to you and `#activity`.
6. **Human Approval Gate**: Inspect the live preview in `#rounds` and tap **Approve & send** only when 100% satisfied.
7. **Support First**: Questions? Contact STPi Support first on WhatsApp **+263 78 460 0904** or **simalidudu@gmail.com** / **tafadzwamchikanya@gmail.com**.
