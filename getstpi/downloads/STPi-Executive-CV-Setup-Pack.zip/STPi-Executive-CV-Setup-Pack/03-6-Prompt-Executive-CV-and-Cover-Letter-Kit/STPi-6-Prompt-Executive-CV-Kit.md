# STPi $19 Executive CV & Cover Letter Setup Pack — The 6-Prompt Kit

> **⚠️ MANDATORY SUPPORT-FIRST RULE:** If anything looks unfamiliar or you need help with your Setup Pack, contact STPi Official Support FIRST via WhatsApp (**+263 78 460 0904**) or Email (**simalidudu@gmail.com** / **tafadzwamchikanya@gmail.com**). Do NOT panic or use random internet advice — if you run to public forums before contacting us first, your account and licence will be removed immediately.
>
> **📝 7-Business-Day Contract Rule:** Please download, print, fill by hand in ink, scan, and email `STPi-Customer-Sales-Contract.pdf` to `simalidudu@gmail.com` within 7 business days of payment, and preserve your physical original copy.

---

## Prompt 1 — Raw CV to Verified YAML Truth-File Extractor
Copy and paste this prompt into your AI assistant (or use it alongside your STPi workspace) with your raw CV text:

```text
You are an executive CV auditor operating under STPi's strict Zero-Fabrication Rule.
Read my raw CV below and convert it into a structured YAML Truth-File with:
1. full_name, email, phone, country, city, headline, summary
2. skills (grouped by core domain, software/tools, and regulatory/compliance)
3. experience (role, company, location, period, and 3-5 factual, action-verb bullet highlights per role)
4. education (qualification, institution, year) and certifications

STRICT RULES:
- Never invent employers, dates, degrees, or numbers not present in my raw text.
- Where a bullet has a real outcome but weak wording, rewrite it using strong executive verbs (Closed, Led, Reduced, Reconciled, Automated, Delivered) while preserving the exact factual truth.
- Flag any missing dates or unclear metrics at the bottom under [QUESTIONS FOR CANDIDATE] so I can supply the real numbers.

[PASTE RAW CV HERE]
```

---

## Prompt 2 — 21-Country ATS Keyword & Competency Gap Audit
Use this prompt to compare your YAML Truth-File against a target vacancy advertisement:

```text
You are an ATS and Executive Recruiter Auditor for Southern, East, and West African + Global Remote markets.
Compare my YAML Truth-File against the Target Vacancy Advertisement below.

Output a 3-part audit table:
1. EXACT MATCHES: Keywords, tools, qualifications, and years of experience in the job ad that are already explicitly in my Truth-File.
2. SYNONYM UPGRADES (SAFE TO REWORD): Skills I genuinely hold in my Truth-File that use different wording from the job ad (show exact phrasing change so the ATS matches 100% without fabricating experience).
3. HARD GAPS (DO NOT FABRICATE): Requirements in the job ad not found in my Truth-File. Ask me if I actually have this experience before adding it.

[PASTE YAML TRUTH-FILE]
[PASTE TARGET JOB AD]
```

---

## Prompt 3 — Fact-Bound Executive Summary & Quantified Bullet Tailoring
Use this prompt to tailor your CV summary and top experience bullets for a specific vacancy:

```text
Using ONLY the facts in my YAML Truth-File, tailor my Executive Summary (3 sentences max) and reorder/refine my Experience bullets for the target role below.

Rules:
- Sentence 1 of Summary: Years of experience + core professional identity + primary qualification.
- Sentence 2 of Summary: Top 3 domain strengths that directly match the employer's vacancy requirements.
- Sentence 3 of Summary: Track record of measurable operational/commercial delivery.
- Reorder bullets inside each role so the most relevant factual achievements appear first.
- Zero hallucination: every company, date, qualification, and metric must come strictly from my Truth-File.

[PASTE YAML TRUTH-FILE]
[PASTE TARGET JOB AD]
```

---

## Prompt 4 — 3-Paragraph Executive Cover Letter & Email Body Writer
Use this prompt to generate the exact 1-page cover letter + email body that accompanies your tailored CV PDF:

```text
Write a crisp, high-conviction 3-paragraph Executive Cover Letter (under 240 words) for the vacancy below using ONLY facts from my YAML Truth-File.

Structure:
- Subject Line: Application: [Exact Job Title] — [My Full Name] ([Top Qualification / Years Experience])
- Paragraph 1 (The Hook): Name the exact role and company, and state my core qualification and years of relevant experience.
- Paragraph 2 (The Proof): Cite 2-3 specific, verified achievements from my Truth-File (with real employers and outcomes) that solve the exact requirements in the job ad.
- Paragraph 3 (The Call to Action): Confirm my location/availability, note that my tailored CV and certificates are attached in a single PDF, and request a brief interview.

Rules: No clichés ("I am writing to express my passionate interest..."), no invented claims, plain executive English.

[PASTE YAML TRUTH-FILE]
[PASTE TARGET JOB AD]
```

---

## Prompt 5 — Direct Hiring Manager / Recruiter Follow-Up (5 Business Days After Sending)
Use this prompt when following up on an approved application in your `#activity` ledger:

```text
Write a polite, 90-word executive follow-up email to the hiring team for [Job Title] at [Company], following up on my application sent 5 business days ago.
Restate 1 concrete factual result from my Truth-File that is directly relevant to their team, confirm my availability for a 15-minute call this week, and keep the tone warm, concise, and respectful.
```

---

## Prompt 6 — Competency & Behavioural Interview Briefing From Your Truth-File
Use this prompt as soon as an employer reply lands in `#activity`:

```text
Based on my YAML Truth-File and the job advertisement below, prepare an Executive Interview Briefing Sheet:
1. The 6 most likely technical and behavioural questions the panel will ask.
2. For each question, draft a structured STAR (Situation, Task, Action, Result) answer drawn strictly from the real roles and achievements in my Truth-File.
3. 3 sharp, commercial questions I should ask the interviewing panel at the end of the interview.
```
